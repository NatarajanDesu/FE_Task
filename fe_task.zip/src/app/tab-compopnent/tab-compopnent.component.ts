import { Component, OnInit } from '@angular/core';
import { TabService } from '../services/tab.service';
//import

@Component({
  selector: 'app-tab-compopnent',
  templateUrl: './tab-compopnent.component.html',
  styleUrls: ['./tab-compopnent.component.css']
})
export class TabCompopnentComponent implements OnInit {
  viewMode = 'tab1';

  constructor(_tabService:TabService) { 
    _tabService.fetchTabData().subscribe((data) =>{
        console.log(data);        
    });
  }

  ngOnInit() {
  }

}
