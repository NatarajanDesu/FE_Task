import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TabCompopnentComponent } from './tab-compopnent/tab-compopnent.component';
import { SliderComponentComponent } from './slider-component/slider-component.component';
import { TabService } from './services/tab.service';
import { HttpClientModule } from '@angular/common/http';


@NgModule({
  declarations: [
    AppComponent,
    TabCompopnentComponent,
    SliderComponentComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [TabService],
  bootstrap: [AppComponent]
})
export class AppModule { }
