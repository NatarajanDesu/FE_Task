import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class TabService {
  tabDataUrl = 'assets/data.json';
  //_http: any;
  constructor(_http:HttpClient) { 

  }
  fetchTabData(){
    return this._http.get<any>(this.tabDataUrl);
  }
}
