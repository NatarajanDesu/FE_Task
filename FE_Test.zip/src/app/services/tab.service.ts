import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
// import { Observable } from 'rxjs/Observable';
// import 'rxjs/Rx';
import { map } from 'rxjs/operators';
import { from } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class TabService {
  tabDataUrl = 'assets/data.json';
  //_http: any;
  constructor(private http:HttpClient) { 

  }

  fetchTabData(){
    return this.http.get<any>(this.tabDataUrl);
    //return this.http.get(this.tabDataUrl).map(data => { return data; });
  }
}
