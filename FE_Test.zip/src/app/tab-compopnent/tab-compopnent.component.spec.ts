import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TabCompopnentComponent } from './tab-compopnent.component';

describe('TabCompopnentComponent', () => {
  let component: TabCompopnentComponent;
  let fixture: ComponentFixture<TabCompopnentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TabCompopnentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TabCompopnentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
