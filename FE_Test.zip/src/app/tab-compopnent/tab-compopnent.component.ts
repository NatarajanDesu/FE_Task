import { Component, OnInit } from '@angular/core';
import { TabService } from '../services/tab.service';
//import

@Component({
  selector: 'app-tab-compopnent',
  templateUrl: './tab-compopnent.component.html',
  styleUrls: ['./tab-compopnent.component.css']
})
export class TabCompopnentComponent implements OnInit {
  viewMode = 1;
  responseData:any[] = [];
  tab_Show:boolean = false;

  constructor(private _tabService:TabService) { 
    _tabService.fetchTabData().subscribe((data) =>{        
        this.responseData = data.data; 
        //console.log(this.responseData);
        this.tab_Show = true;
    });
  }

  ngOnInit() {
  }

  showTab(data){
    console.log(data);
    this.viewMode = data;
  }

 
}
