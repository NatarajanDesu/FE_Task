import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Ng5SliderModule } from 'ng5-slider';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TabCompopnentComponent } from './tab-compopnent/tab-compopnent.component';
import { SliderComponentComponent } from './slider-component/slider-component.component';
import { TabService } from './services/tab.service';
import { HttpClientModule } from '@angular/common/http';


@NgModule({
  declarations: [
    AppComponent,
    TabCompopnentComponent,
    SliderComponentComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    Ng5SliderModule
  ],
  providers: [TabService],
  bootstrap: [AppComponent]
})
export class AppModule { }
