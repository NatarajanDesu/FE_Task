import { Component, OnInit } from '@angular/core';
import { Options } from 'ng5-slider';
import { TabService } from 'src/app/services/tab.service';

@Component({
  selector: 'app-slider-component',
  templateUrl: './slider-component.component.html',
  styleUrls: ['./slider-component.component.css']
})
export class SliderComponentComponent implements OnInit {
  
  responseData:any[] = [];
  slider_Show:boolean =false;
  value: number = 1;
  highValue: number = 4;
  options: Options = {
    floor: 0,
    ceil: 5
  };
  sliderValue:any = [];
  constructor(private _tabService:TabService) {

    _tabService.fetchTabData().subscribe((data) =>{        
        this.responseData = data.data; 
        this.findMinMaxValue(this.responseData);
        //Math.min.apply(Math,$scope.data.map(function(item){return item.age;}));
        //this.slider_Show = true;
    });
    
  }

  ngOnInit() {
  }

  findMinMaxValue(_res){
    let sliderMinValue:number = 0;
    let sliderMaxValue:number = 0;
    _res.forEach(element => {this.sliderValue.push(element.tab_id);});
    this.value = this.sliderValue.reduce((a, b) => Math.min(a, b));
    this.highValue = this.sliderValue.reduce((a, b) => Math.max(a, b));
    this.slider_Show = true;
  }
  

}
